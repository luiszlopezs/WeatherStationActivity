/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package actividadpatronobserver;

/**
 *
 * @author hailen
 */
public class CurrentConditionDisplay implements Observer, DisplayElement {
    private float temperatura;
    private float humedad;
    private Subject weatherData;

    public CurrentConditionDisplay(Subject weatherData) {
        this.weatherData = weatherData;
        weatherData.registerObserver(this);
    }

    @Override
    public void update(float temperatura, float humedad, float presion) {
        this.temperatura = temperatura;
        this.humedad= humedad;
        display();
    }

    @Override
    public void display() {
        System.out.println("Condiciones actuales: " + temperatura+ "C y " + humedad + "% humedad");
    }
}
