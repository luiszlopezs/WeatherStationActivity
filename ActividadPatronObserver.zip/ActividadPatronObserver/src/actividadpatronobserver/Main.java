/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package actividadpatronobserver;

/**
 *
 * @author hailen
 */
public class Main {
    public static void main(String[] args) {
        WeatherData weatherData = new WeatherData();

        CurrentConditionDisplay currentDisplay = new CurrentConditionDisplay(weatherData);
        StatisticsDisplay statisticsDisplay = new StatisticsDisplay(weatherData);
        ForecastDisplay forecastDisplay = new ForecastDisplay(weatherData);
        HeatIndexDisplay heatIndexDisplay = new HeatIndexDisplay(weatherData);
        PressureDisplay pressureDisplay = new PressureDisplay(weatherData);

        System.out.println("---- Primera actualizacion ----");
        weatherData.setMediciones(30, 65, 1010);

        System.out.println("---- Segunda actualizacion ----");
        weatherData.setMediciones(32, 70, 1005);

        System.out.println("---- Tercera actualizacion ----");
        weatherData.setMediciones(28, 90, 1002);
    }
}
