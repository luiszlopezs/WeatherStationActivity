/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package actividadpatronobserver;

/**
 *
 * @author hailen
 */
public class ForecastDisplay implements Observer, DisplayElement {
    private float ultimaPresion;
    private float presionActual = 1013; 
    private Subject weatherData;

    public ForecastDisplay(Subject weatherData) {
        this.weatherData = weatherData;
        weatherData.registerObserver(this);
    }

    @Override
    public void update(float temperatura, float humedad, float presion) {
        ultimaPresion = presionActual;
        presionActual = presion;
        display();
    }

    @Override
    public void display() {
        System.out.print("Pronostico: ");
        if (presionActual > ultimaPresion) {
            System.out.println("El clima esta mejorando");
        } else if (presionActual == ultimaPresion) {
            System.out.println("Sin cambios");
        } else {
            System.out.println("Es probable que llueva");
        }
    }
}
