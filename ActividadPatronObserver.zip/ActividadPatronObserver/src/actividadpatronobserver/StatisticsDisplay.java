/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package actividadpatronobserver;

/**
 *
 * @author hailen
 */
import java.util.*;

public class StatisticsDisplay implements Observer, DisplayElement {
    private ArrayList<Float> lecturasTemps = new ArrayList<>();
    private Subject weatherData;

    public StatisticsDisplay(Subject weatherData) {
        this.weatherData = weatherData;
        weatherData.registerObserver(this);
    }

    @Override
    public void update(float temperatura, float humedad, float presion) {
        lecturasTemps.add(temperatura);
        display();
    }

    @Override
    public void display() {
        float sum = 0;
        for (float t : lecturasTemps) sum += t;
        float avg = sum / lecturasTemps.size();
        float max = Collections.max(lecturasTemps);
        float min = Collections.min(lecturasTemps);

        System.out.println("Estadisticas -> Promedio: " + avg + "C, Max: " + max + "C, Min: " + min + "C");
    }
}
